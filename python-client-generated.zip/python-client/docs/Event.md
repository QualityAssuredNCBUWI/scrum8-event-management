# Event

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**title** | **str** |  | [optional] 
**created_at** | **date** |  | [optional] 
**start_date** | **date** |  | [optional] 
**end_date** | **date** |  | [optional] 
**description** | **str** |  | [optional] 
**venue** | **str** |  | [optional] 
**imageflyer** | **str** |  | [optional] 
**website_url** | **str** |  | [optional] 
**status** | **str** | The status of event | [optional] 
**uid** | **str** | user id of user who created the event | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


