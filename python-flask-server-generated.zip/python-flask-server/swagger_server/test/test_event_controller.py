# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.api_response import ApiResponse  # noqa: E501
from swagger_server.models.event import Event  # noqa: E501
from swagger_server.models.pet import Pet  # noqa: E501
from swagger_server.test import BaseTestCase


class TestEventController(BaseTestCase):
    """EventController integration test stubs"""

    def test_add_event(self):
        """Test case for add_event

        Add a new event
        """
        body = Event()
        response = self.client.open(
            '/v2/event',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_api_event_event_id_put(self):
        """Test case for api_event_event_id_put

        Edit event by ID
        """
        response = self.client.open(
            '/v2/api/event/{eventId}'.format(eventId=56),
            method='PUT')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_getevent_by_id(self):
        """Test case for getevent_by_id

        Find event by ID
        """
        response = self.client.open(
            '/v2/api/event/{eventId}'.format(eventId=789),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_remove_event(self):
        """Test case for remove_event

        Delete event
        """
        response = self.client.open(
            '/v2/api/event/{eventId}'.format(eventId=789),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_pet(self):
        """Test case for update_pet

        Update an existing pet
        """
        body = Pet()
        response = self.client.open(
            '/v2/event',
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
