import connexion
import six

from swagger_server.models.api_response import ApiResponse  # noqa: E501
from swagger_server.models.event import Event  # noqa: E501
from swagger_server.models.pet import Pet  # noqa: E501
from swagger_server import util


def add_event(body):  # noqa: E501
    """Add a new event

     # noqa: E501

    :param body: Parameters needed for the creation of a new Event object
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Event.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def api_event_event_id_put(eventId):  # noqa: E501
    """Edit event by ID

    make and edit to a single Event based on ID number # noqa: E501

    :param eventId: 
    :type eventId: int

    :rtype: Event
    """
    return 'do some magic!'


def getevent_by_id(eventId):  # noqa: E501
    """Find event by ID

    Returns a single pet # noqa: E501

    :param eventId: ID of event to return
    :type eventId: int

    :rtype: Event
    """
    return 'do some magic!'


def remove_event(eventId):  # noqa: E501
    """Delete event

    Delete event by Id # noqa: E501

    :param eventId: 
    :type eventId: int

    :rtype: Event
    """
    return 'do some magic!'


def update_pet(body):  # noqa: E501
    """Update an existing pet

     # noqa: E501

    :param body: Pet object that needs to be added to the store
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Pet.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
